﻿
namespace ImageShow
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.header = new System.Windows.Forms.RichTextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBoximagesource = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonimagefrominternet = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxtime = new System.Windows.Forms.TextBox();
            this.buttonshowimage = new System.Windows.Forms.Button();
            this.buttonChangeSlideTime = new System.Windows.Forms.Button();
            this.buttonStop = new System.Windows.Forms.Button();
            this.buttonStart = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.slidepicture = new System.Windows.Forms.PictureBox();
            this.buttonnextimage = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.timerfade = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.slidepicture)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.header);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(958, 100);
            this.panel1.TabIndex = 0;
            // 
            // header
            // 
            this.header.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.header.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.header.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.header.ForeColor = System.Drawing.Color.Red;
            this.header.Location = new System.Drawing.Point(219, 12);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(670, 60);
            this.header.TabIndex = 1;
            this.header.Text = "Drift Cars\' Images Slideshow";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(166, 100);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panel3.Controls.Add(this.buttonnextimage);
            this.panel3.Controls.Add(this.textBoximagesource);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.buttonimagefrominternet);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.textBoxtime);
            this.panel3.Controls.Add(this.buttonshowimage);
            this.panel3.Controls.Add(this.buttonChangeSlideTime);
            this.panel3.Controls.Add(this.buttonStop);
            this.panel3.Controls.Add(this.buttonStart);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(758, 100);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 431);
            this.panel3.TabIndex = 0;
            // 
            // textBoximagesource
            // 
            this.textBoximagesource.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.textBoximagesource.Location = new System.Drawing.Point(99, 294);
            this.textBoximagesource.Name = "textBoximagesource";
            this.textBoximagesource.Size = new System.Drawing.Size(64, 20);
            this.textBoximagesource.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 297);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter image source";
            // 
            // buttonimagefrominternet
            // 
            this.buttonimagefrominternet.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonimagefrominternet.Location = new System.Drawing.Point(8, 323);
            this.buttonimagefrominternet.Name = "buttonimagefrominternet";
            this.buttonimagefrominternet.Size = new System.Drawing.Size(93, 105);
            this.buttonimagefrominternet.TabIndex = 3;
            this.buttonimagefrominternet.Text = "Show image from internet";
            this.buttonimagefrominternet.UseVisualStyleBackColor = true;
            this.buttonimagefrominternet.Click += new System.EventHandler(this.buttonimagefrominternet_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Enter slide time";
            // 
            // textBoxtime
            // 
            this.textBoxtime.Location = new System.Drawing.Point(87, 112);
            this.textBoxtime.Name = "textBoxtime";
            this.textBoxtime.Size = new System.Drawing.Size(76, 20);
            this.textBoxtime.TabIndex = 1;
            this.textBoxtime.TextChanged += new System.EventHandler(this.textBoxtime_TextChanged);
            // 
            // buttonshowimage
            // 
            this.buttonshowimage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonshowimage.Location = new System.Drawing.Point(43, 204);
            this.buttonshowimage.Name = "buttonshowimage";
            this.buttonshowimage.Size = new System.Drawing.Size(120, 78);
            this.buttonshowimage.TabIndex = 0;
            this.buttonshowimage.Text = "Show Image From Directory";
            this.buttonshowimage.UseVisualStyleBackColor = true;
            this.buttonshowimage.Click += new System.EventHandler(this.buttonshowimage_Click);
            // 
            // buttonChangeSlideTime
            // 
            this.buttonChangeSlideTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonChangeSlideTime.Location = new System.Drawing.Point(43, 138);
            this.buttonChangeSlideTime.Name = "buttonChangeSlideTime";
            this.buttonChangeSlideTime.Size = new System.Drawing.Size(120, 60);
            this.buttonChangeSlideTime.TabIndex = 0;
            this.buttonChangeSlideTime.Text = "Change Slide Time";
            this.buttonChangeSlideTime.UseVisualStyleBackColor = true;
            this.buttonChangeSlideTime.Click += new System.EventHandler(this.buttonChangeSlideTime_Click);
            // 
            // buttonStop
            // 
            this.buttonStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonStop.Location = new System.Drawing.Point(43, 60);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(120, 50);
            this.buttonStop.TabIndex = 0;
            this.buttonStop.Text = "Stop";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // buttonStart
            // 
            this.buttonStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonStart.Location = new System.Drawing.Point(43, 6);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(120, 50);
            this.buttonStart.TabIndex = 0;
            this.buttonStart.Text = "Start";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 2000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // slidepicture
            // 
            this.slidepicture.BackColor = System.Drawing.Color.Yellow;
            this.slidepicture.Dock = System.Windows.Forms.DockStyle.Fill;
            this.slidepicture.Image = ((System.Drawing.Image)(resources.GetObject("slidepicture.Image")));
            this.slidepicture.Location = new System.Drawing.Point(0, 100);
            this.slidepicture.Name = "slidepicture";
            this.slidepicture.Size = new System.Drawing.Size(758, 431);
            this.slidepicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slidepicture.TabIndex = 0;
            this.slidepicture.TabStop = false;
            // 
            // buttonnextimage
            // 
            this.buttonnextimage.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonnextimage.Location = new System.Drawing.Point(108, 323);
            this.buttonnextimage.Name = "buttonnextimage";
            this.buttonnextimage.Size = new System.Drawing.Size(75, 105);
            this.buttonnextimage.TabIndex = 6;
            this.buttonnextimage.Text = "Next Image";
            this.buttonnextimage.UseVisualStyleBackColor = true;
            this.buttonnextimage.Click += new System.EventHandler(this.buttonnextimage_Click);
            // 
            // timerfade
            // 
            this.timerfade.Interval = 500;
            this.timerfade.Tick += new System.EventHandler(this.timerfade_Tick);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(958, 531);
            this.Controls.Add(this.slidepicture);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.slidepicture)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button buttonshowimage;
        private System.Windows.Forms.Button buttonChangeSlideTime;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.PictureBox slidepicture;
        private System.Windows.Forms.RichTextBox header;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox textBoxtime;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonimagefrominternet;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoximagesource;
        private System.Windows.Forms.Button buttonnextimage;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Timer timerfade;
    }
}

