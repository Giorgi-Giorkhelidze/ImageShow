﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;

namespace ImageShow
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

    
       
        private int imagenumber = 1;


        private void loadnextimage()
        {
            
             if (imagenumber == 8)
             {
                 imagenumber = 1;

             }

           // slidepicture.ImageLocation =string.Format( @"images\{0}.png",imagenumber);
            slidepicture.ImageLocation = string.Format(@"images\{0}.jpg", imagenumber);
            imagenumber++;      
           
        }
      

        private void timer1_Tick(object sender, EventArgs e)
        {           
            loadnextimage();
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
        }

        private void buttonChangeSlideTime_Click(object sender, EventArgs e)
        {
            if (textBoxtime.Text == "")
            {
                MessageBox.Show("You did not entered time", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int time = Convert.ToInt32(textBoxtime.Text);
                timer1.Interval = time;
                MessageBox.Show("Slide time changed successfuly", "Change time", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void textBoxtime_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBoxtime.Text, "  ^ [0-9]"))
            {
                textBoxtime.Text = "";
            }
            
            
        }

        private void buttonshowimage_Click(object sender, EventArgs e)
        {
              
            OpenFileDialog open = new OpenFileDialog();

            open.Filter = "Image Files(*.jpg; *.png; *.gif; *.bmp)|*.jpg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {

                slidepicture.Image = new Bitmap(open.FileName);

            }
        }

        WebClient wc = new WebClient();

        private void buttonimagefrominternet_Click(object sender, EventArgs e)
        {
            if (textBoximagesource.Text == "")
            {
                MessageBox.Show("You did not entered directory", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else { 
                wc.DownloadFileCompleted += new AsyncCompletedEventHandler(filedownload);
                Uri imageurl = new Uri(textBoximagesource.Text);
                wc.DownloadFileAsync(imageurl, "myfile.jpg");

                OpenFileDialog open = new OpenFileDialog();

                open.Filter = "Image Files(*.jpg; *.png; *.gif; *.bmp)|*.jpg; *.gif; *.bmp";
                if (open.ShowDialog() == DialogResult.OK)
                {

                    slidepicture.Image = new Bitmap(open.FileName);

                }
            }
        }

        private void filedownload(object sender, AsyncCompletedEventArgs e)
        {
            MessageBox.Show("Download completed and choose 'myfile.jpg'");
        }

        private void buttonnextimage_Click(object sender, EventArgs e)
        {
            loadnextimage();
        }


        int opacity = 0;      
           

        private void timerfade_Tick(object sender, EventArgs e)
        {
            if (opacity < 255)
            {
                Image img = slidepicture.Image;
                using (Graphics g = Graphics.FromImage(img))
                {
                    Pen pen = new Pen(Color.FromArgb(opacity, 255, 255, 255), img.Width);
                    g.DrawLine(pen, -1, -1, img.Width, img.Height);
                    g.Save();
                }
                slidepicture.Image = img;
                opacity++;
            }
            else
            {
                timerfade.Stop();
            }
        }         
        
    }
}

       

